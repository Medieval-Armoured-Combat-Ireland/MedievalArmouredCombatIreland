<?php
/**
 * The Front Page template file.
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0.31
 */

get_header();

// If front-page is a static page
if (get_option('show_on_front') == 'page') {

	// If Front Page Builder is enabled - display sections
	if (kings_queens_is_on(kings_queens_get_theme_option('front_page_enabled'))) {

		if ( have_posts() ) the_post();

		$kings_queens_sections = kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('front_page_sections'), 1, false);
		if (is_array($kings_queens_sections)) {
			foreach ($kings_queens_sections as $kings_queens_section) {
				get_template_part("front-page/section", $kings_queens_section);
			}
		}
	
	// Else if this page is blog archive
	} else if (is_page_template('blog.php')) {
		get_template_part('blog');

	// Else - display native page content
	} else {
		get_template_part('page');
	}

// Else get index template to show posts
} else {
	get_template_part('index');
}

get_footer();
?>