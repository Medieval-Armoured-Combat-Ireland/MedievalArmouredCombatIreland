<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

$kings_queens_blog_style = explode('_', kings_queens_get_theme_option('blog_style'));
$kings_queens_columns = empty($kings_queens_blog_style[1]) ? 2 : max(2, $kings_queens_blog_style[1]);
$kings_queens_expanded = !kings_queens_sidebar_present() && kings_queens_is_on(kings_queens_get_theme_option('expand_content'));
$kings_queens_post_format = get_post_format();
$kings_queens_post_format = empty($kings_queens_post_format) ? 'standard' : str_replace('post-format-', '', $kings_queens_post_format);
$kings_queens_animation = kings_queens_get_theme_option('blog_animation');
$kings_queens_components = kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('meta_parts'));
$kings_queens_counters = kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('counters'));

?><div class="<?php echo 'classic' == $kings_queens_blog_style[0] ? 'column' : 'masonry_item masonry_item'; ?>-1_<?php echo esc_attr($kings_queens_columns); ?>"><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_format_'.esc_attr($kings_queens_post_format)
					. ' post_layout_classic post_layout_classic_'.esc_attr($kings_queens_columns)
					. ' post_layout_'.esc_attr($kings_queens_blog_style[0]) 
					. ' post_layout_'.esc_attr($kings_queens_blog_style[0]).'_'.esc_attr($kings_queens_columns)
					); ?>
	<?php echo (!kings_queens_is_off($kings_queens_animation) ? ' data-animation="'.esc_attr(kings_queens_get_animation_classes($kings_queens_animation)).'"' : ''); ?>>
	<?php

	// Sticky label
	if ( is_sticky() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	kings_queens_show_post_featured( array( 'thumb_size' => kings_queens_get_thumb_size($kings_queens_blog_style[0] == 'classic'
													? (strpos(kings_queens_get_theme_option('body_style'), 'full')!==false 
															? ( $kings_queens_columns > 2 ? 'big' : 'huge' )
															: (	$kings_queens_columns > 2
																? ($kings_queens_expanded ? 'med' : 'small')
																: ($kings_queens_expanded ? 'big' : 'med')
																)
														)
													: (strpos(kings_queens_get_theme_option('body_style'), 'full')!==false 
															? ( $kings_queens_columns > 2 ? 'masonry-big' : 'full' )
															: (	$kings_queens_columns <= 2 && $kings_queens_expanded ? 'masonry-big' : 'masonry')
														)
								) ) );

	if ( !in_array($kings_queens_post_format, array('link', 'aside', 'status', 'quote')) ) {
		?>
		<div class="post_header entry-header">
			<?php 
			do_action('kings_queens_action_before_post_title'); 

			// Post title
			the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );

			do_action('kings_queens_action_before_post_meta'); 

			// Post meta
			if (!empty($kings_queens_components))
				kings_queens_show_post_meta(apply_filters('kings_queens_filter_post_meta_args', array(
					'components' => $kings_queens_components,
					'counters' => $kings_queens_counters,
					'seo' => false
					), $kings_queens_blog_style[0], $kings_queens_columns)
				);

			do_action('kings_queens_action_after_post_meta'); 
			?>
		</div><!-- .entry-header -->
		<?php
	}		
	?>

	<div class="post_content entry-content">
		<div class="post_content_inner">
			<?php
			$kings_queens_show_learn_more = false;
			if (has_excerpt()) {
				the_excerpt();
			} else if (strpos(get_the_content('!--more'), '!--more')!==false) {
				the_content( '' );
			} else if (in_array($kings_queens_post_format, array('link', 'aside', 'status'))) {
				the_content();
			} else if ($kings_queens_post_format == 'quote') {
				if (($quote = kings_queens_get_tag(get_the_content(), '<blockquote>', '</blockquote>'))!='')
					kings_queens_show_layout(wpautop($quote));
				else
					the_excerpt();
			} else if (substr(get_the_content(), 0, 4)!='[vc_') {
				the_excerpt();
			}
			?>
		</div>
		<?php
		// Post meta
		if (in_array($kings_queens_post_format, array('link', 'aside', 'status', 'quote'))) {
			if (!empty($kings_queens_components))
				kings_queens_show_post_meta(apply_filters('kings_queens_filter_post_meta_args', array(
					'components' => $kings_queens_components,
					'counters' => $kings_queens_counters
					), $kings_queens_blog_style[0], $kings_queens_columns)
				);
		}
		// More button
		if ( $kings_queens_show_learn_more ) {
			?><p><a class="more-link" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'kings-queens'); ?></a></p><?php
		}
		?>
	</div><!-- .entry-content -->

</article></div>