<?php
/**
 * The template for homepage posts with "Excerpt" style
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

kings_queens_storage_set('blog_archive', true);

get_header(); 

if (have_posts()) {

	kings_queens_show_layout(get_query_var('blog_archive_start'));

	?><div class="posts_container"><?php
	
	$kings_queens_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$kings_queens_sticky_out = kings_queens_get_theme_option('sticky_style')=='columns' 
							&& is_array($kings_queens_stickies) && count($kings_queens_stickies) > 0 && get_query_var( 'paged' ) < 1;
	if ($kings_queens_sticky_out) {
		?><div class="sticky_wrap columns_wrap"><?php	
	}
	while ( have_posts() ) { the_post(); 
		if ($kings_queens_sticky_out && !is_sticky()) {
			$kings_queens_sticky_out = false;
			?></div><?php
		}
		get_template_part( 'content', $kings_queens_sticky_out && is_sticky() ? 'sticky' : 'excerpt' );
	}
	if ($kings_queens_sticky_out) {
		$kings_queens_sticky_out = false;
		?></div><?php
	}
	
	?></div><?php

	kings_queens_show_pagination();

	kings_queens_show_layout(get_query_var('blog_archive_end'));

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>