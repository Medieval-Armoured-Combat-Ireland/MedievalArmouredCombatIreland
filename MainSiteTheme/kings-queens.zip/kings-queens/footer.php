<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

						// Widgets area inside page content
						kings_queens_create_widgets_area('widgets_below_content');
						?>				
					</div><!-- </.content> -->

					<?php
					// Show main sidebar
					get_sidebar();

					// Widgets area below page content
					kings_queens_create_widgets_area('widgets_below_page');

					$kings_queens_body_style = kings_queens_get_theme_option('body_style');
					if ($kings_queens_body_style != 'fullscreen') {
						?></div><!-- </.content_wrap> --><?php
					}
					?>
			</div><!-- </.page_content_wrap> -->

			<?php
			// Footer
			$kings_queens_footer_type = kings_queens_get_theme_option("footer_type");
			if ($kings_queens_footer_type == 'custom' && !kings_queens_is_layouts_available())
				$kings_queens_footer_type = 'default';
			get_template_part( "templates/footer-{$kings_queens_footer_type}");
			?>

		</div><!-- /.page_wrap -->

	</div><!-- /.body_wrap -->

	<?php if (kings_queens_is_on(kings_queens_get_theme_option('debug_mode')) && kings_queens_get_file_dir('images/makeup.jpg')!='') { ?>
		<img src="<?php echo esc_url(kings_queens_get_file_url('images/makeup.jpg')); ?>" id="makeup">
	<?php } ?>

	<?php wp_footer(); ?>

</body>
</html>