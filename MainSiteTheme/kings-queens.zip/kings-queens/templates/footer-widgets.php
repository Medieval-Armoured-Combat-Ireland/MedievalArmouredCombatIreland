<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0.10
 */

// Footer sidebar
$kings_queens_footer_name = kings_queens_get_theme_option('footer_widgets');
$kings_queens_footer_present = !kings_queens_is_off($kings_queens_footer_name) && is_active_sidebar($kings_queens_footer_name);
if ($kings_queens_footer_present) { 
	kings_queens_storage_set('current_sidebar', 'footer');
	$kings_queens_footer_wide = kings_queens_get_theme_option('footer_wide');
	ob_start();
	if ( is_active_sidebar($kings_queens_footer_name) ) {
		dynamic_sidebar($kings_queens_footer_name);
	}
	$kings_queens_out = trim(ob_get_contents());
	ob_end_clean();
	if (!empty($kings_queens_out)) {
		$kings_queens_out = preg_replace("/<\\/aside>[\r\n\s]*<aside/", "</aside><aside", $kings_queens_out);
		$kings_queens_need_columns = true;	//or check: strpos($kings_queens_out, 'columns_wrap')===false;
		if ($kings_queens_need_columns) {
			$kings_queens_columns = max(0, (int) kings_queens_get_theme_option('footer_columns'));
			if ($kings_queens_columns == 0) $kings_queens_columns = min(4, max(1, substr_count($kings_queens_out, '<aside ')));
			if ($kings_queens_columns > 1)
				$kings_queens_out = preg_replace("/<aside([^>]*)class=\"widget/", "<aside$1class=\"column-1_".esc_attr($kings_queens_columns).' widget', $kings_queens_out);
			else
				$kings_queens_need_columns = false;
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo !empty($kings_queens_footer_wide) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<div class="footer_widgets_inner widget_area_inner">
				<?php 
				if (!$kings_queens_footer_wide) { 
					?><div class="content_wrap"><?php
				}
				if ($kings_queens_need_columns) {
					?><div class="columns_wrap"><?php
				}
				do_action( 'kings_queens_action_before_sidebar' );
				kings_queens_show_layout($kings_queens_out);
				do_action( 'kings_queens_action_after_sidebar' );
				if ($kings_queens_need_columns) {
					?></div><!-- /.columns_wrap --><?php
				}
				if (!$kings_queens_footer_wide) {
					?></div><!-- /.content_wrap --><?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
?>