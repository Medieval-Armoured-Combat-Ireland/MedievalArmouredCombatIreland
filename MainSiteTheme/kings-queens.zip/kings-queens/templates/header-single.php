<?php
/**
 * The template to display the featured image in the single post
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

?>