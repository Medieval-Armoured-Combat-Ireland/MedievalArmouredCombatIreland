<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap<?php
				if (!kings_queens_is_inherit(kings_queens_get_theme_option('copyright_scheme')))
					echo ' scheme_' . esc_attr(kings_queens_get_theme_option('copyright_scheme'));
 				?>">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text"><?php
				$kings_queens_copyright = kings_queens_get_theme_option('copyright');
				if (!empty($kings_queens_copyright)) {
					// Replace {{Y}} or {Y} with the current year
					$kings_queens_copyright = str_replace(array('{{Y}}', '{Y}'), date('Y'), $kings_queens_copyright);
					// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
					$kings_queens_copyright = kings_queens_prepare_macros($kings_queens_copyright);
					// Display copyright
					echo wp_kses_data(nl2br($kings_queens_copyright));
				}
			?></div>
		</div>
	</div>
</div>
