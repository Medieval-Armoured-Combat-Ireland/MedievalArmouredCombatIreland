<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

// Page (category, tag, archive, author) title

if ( kings_queens_need_page_title() && !is_front_page()) {
	kings_queens_sc_layouts_showed('title', true);
	kings_queens_sc_layouts_showed('postmeta', true);
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal scheme_dark">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() )  {
							?><div class="sc_layouts_title_meta"><?php
								kings_queens_show_post_meta(apply_filters('kings_queens_filter_post_meta_args', array(
									'components' => kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('meta_parts')),
									'counters' => kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('counters')),
									'seo' => kings_queens_is_on(kings_queens_get_theme_option('seo_snippets'))
									), 'header', 1)
								);
							?></div><?php
						}
						
						// Blog/Post title
						?><div class="sc_layouts_title_title"><?php
							$kings_queens_blog_title = kings_queens_get_blog_title();
							$kings_queens_blog_title_text = $kings_queens_blog_title_class = $kings_queens_blog_title_link = $kings_queens_blog_title_link_text = '';
							if (is_array($kings_queens_blog_title)) {
								$kings_queens_blog_title_text = $kings_queens_blog_title['text'];
								$kings_queens_blog_title_class = !empty($kings_queens_blog_title['class']) ? ' '.$kings_queens_blog_title['class'] : '';
								$kings_queens_blog_title_link = !empty($kings_queens_blog_title['link']) ? $kings_queens_blog_title['link'] : '';
								$kings_queens_blog_title_link_text = !empty($kings_queens_blog_title['link_text']) ? $kings_queens_blog_title['link_text'] : '';
							} else
								$kings_queens_blog_title_text = $kings_queens_blog_title;
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr($kings_queens_blog_title_class); ?>"><?php
								$kings_queens_top_icon = kings_queens_get_category_icon();
								if (!empty($kings_queens_top_icon)) {
									$kings_queens_attr = kings_queens_getimagesize($kings_queens_top_icon);
									?><img src="<?php echo esc_url($kings_queens_top_icon); ?>" alt="<?php echo esc_attr($kings_queens_blog_title_text);?>" <?php if (!empty($kings_queens_attr[3])) kings_queens_show_layout($kings_queens_attr[3]);?>><?php
								}
								echo wp_kses($kings_queens_blog_title_text, 'kings_queens_kses_content');
							?></h1>
							<?php
							if (!empty($kings_queens_blog_title_link) && !empty($kings_queens_blog_title_link_text)) {
								?><a href="<?php echo esc_url($kings_queens_blog_title_link); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html($kings_queens_blog_title_link_text); ?></a><?php
							}
							
							// Category/Tag description
							if ( is_category() || is_tag() || is_tax() ) 
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
		
						?></div><?php
	
						// Breadcrumbs
						?><div class="sc_layouts_title_breadcrumbs"><?php
							do_action( 'kings_queens_action_breadcrumbs');
						?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
?>