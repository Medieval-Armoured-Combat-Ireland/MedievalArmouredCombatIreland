<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

$kings_queens_args = get_query_var('kings_queens_logo_args');

// Site logo
$kings_queens_logo_type   = isset($kings_queens_args['type']) ? $kings_queens_args['type'] : '';
$kings_queens_logo_image  = kings_queens_get_logo_image($kings_queens_logo_type);
$kings_queens_logo_text   = kings_queens_is_on(kings_queens_get_theme_option('logo_text')) ? get_bloginfo( 'name' ) : '';
$kings_queens_logo_slogan = get_bloginfo( 'description', 'display' );
if (!empty($kings_queens_logo_image) || !empty($kings_queens_logo_text)) {
	?><a class="sc_layouts_logo" href="<?php echo is_front_page() ? '#' : esc_url(home_url('/')); ?>"><?php
		if (!empty($kings_queens_logo_image)) {
			if (empty($kings_queens_logo_type) && function_exists('the_custom_logo') && is_numeric( $kings_queens_logo_image ) && $kings_queens_logo_image > 0 ) {
				the_custom_logo();
			} else {
				$kings_queens_attr = kings_queens_getimagesize($kings_queens_logo_image);
				echo '<img src="'.esc_url($kings_queens_logo_image).'" alt="'.esc_attr($kings_queens_logo_text).'"'.(!empty($kings_queens_attr[3]) ? ' '.wp_kses_data($kings_queens_attr[3]) : '').'>';
			}
		} else {
			kings_queens_show_layout(kings_queens_prepare_macros($kings_queens_logo_text), '<span class="logo_text">', '</span>');
			kings_queens_show_layout(kings_queens_prepare_macros($kings_queens_logo_slogan), '<span class="logo_slogan">', '</span>');
		}
	?></a><?php
}
?>