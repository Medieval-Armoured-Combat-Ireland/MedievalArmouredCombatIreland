<?php
/**
 * The template to display the site logo in the footer
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0.10
 */

// Logo
if (kings_queens_is_on(kings_queens_get_theme_option('logo_in_footer'))) {
	$kings_queens_logo_image = '';
	if (kings_queens_is_on(kings_queens_get_theme_option('logo_retina_enabled')) && kings_queens_get_retina_multiplier() > 1)
		$kings_queens_logo_image = kings_queens_get_theme_option( 'logo_footer_retina' );
	if (empty($kings_queens_logo_image)) 
		$kings_queens_logo_image = kings_queens_get_theme_option( 'logo_footer' );
	$kings_queens_logo_text   = get_bloginfo( 'name' );
	if (!empty($kings_queens_logo_image) || !empty($kings_queens_logo_text)) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if (!empty($kings_queens_logo_image)) {
					$kings_queens_attr = kings_queens_getimagesize($kings_queens_logo_image);
					echo '<a href="'.esc_url(home_url('/')).'"><img src="'.esc_url($kings_queens_logo_image).'" class="logo_footer_image" alt=" ' . esc_attr($kings_queens_logo_text) . ' " '.(!empty($kings_queens_attr[3]) ? ' ' . wp_kses_data($kings_queens_attr[3]) : '').'></a>' ;
				} else if (!empty($kings_queens_logo_text)) {
					echo '<h1 class="logo_footer_text"><a href="'.esc_url(home_url('/')).'">' . esc_html($kings_queens_logo_text) . '</a></h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
?>