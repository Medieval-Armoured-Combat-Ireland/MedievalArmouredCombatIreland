<?php
/**
 * The template for homepage posts with "Portfolio" style
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

kings_queens_storage_set('blog_archive', true);

get_header(); 

if (have_posts()) {

	kings_queens_show_layout(get_query_var('blog_archive_start'));

	$kings_queens_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$kings_queens_sticky_out = kings_queens_get_theme_option('sticky_style')=='columns' 
							&& is_array($kings_queens_stickies) && count($kings_queens_stickies) > 0 && get_query_var( 'paged' ) < 1;
	
	// Show filters
	$kings_queens_cat = kings_queens_get_theme_option('parent_cat');
	$kings_queens_post_type = kings_queens_get_theme_option('post_type');
	$kings_queens_taxonomy = kings_queens_get_post_type_taxonomy($kings_queens_post_type);
	$kings_queens_show_filters = kings_queens_get_theme_option('show_filters');
	$kings_queens_tabs = array();
	if (!kings_queens_is_off($kings_queens_show_filters)) {
		$kings_queens_args = array(
			'type'			=> $kings_queens_post_type,
			'child_of'		=> $kings_queens_cat,
			'orderby'		=> 'name',
			'order'			=> 'ASC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 0,
			'taxonomy'		=> $kings_queens_taxonomy,
			'pad_counts'	=> false
		);
		$kings_queens_portfolio_list = get_terms($kings_queens_args);
		if (is_array($kings_queens_portfolio_list) && count($kings_queens_portfolio_list) > 0) {
			$kings_queens_tabs[$kings_queens_cat] = esc_html__('All', 'kings-queens');
			foreach ($kings_queens_portfolio_list as $kings_queens_term) {
				if (isset($kings_queens_term->term_id)) $kings_queens_tabs[$kings_queens_term->term_id] = $kings_queens_term->name;
			}
		}
	}
	if (count($kings_queens_tabs) > 0) {
		$kings_queens_portfolio_filters_ajax = true;
		$kings_queens_portfolio_filters_active = $kings_queens_cat;
		$kings_queens_portfolio_filters_id = 'portfolio_filters';
		?>
		<div class="portfolio_filters kings_queens_tabs kings_queens_tabs_ajax">
			<ul class="portfolio_titles kings_queens_tabs_titles">
				<?php
				foreach ($kings_queens_tabs as $kings_queens_id=>$kings_queens_title) {
					?><li><a href="<?php echo esc_url(kings_queens_get_hash_link(sprintf('#%s_%s_content', $kings_queens_portfolio_filters_id, $kings_queens_id))); ?>" data-tab="<?php echo esc_attr($kings_queens_id); ?>"><?php echo esc_html($kings_queens_title); ?></a></li><?php
				}
				?>
			</ul>
			<?php
			$kings_queens_ppp = kings_queens_get_theme_option('posts_per_page');
			if (kings_queens_is_inherit($kings_queens_ppp)) $kings_queens_ppp = '';
			foreach ($kings_queens_tabs as $kings_queens_id=>$kings_queens_title) {
				$kings_queens_portfolio_need_content = $kings_queens_id==$kings_queens_portfolio_filters_active || !$kings_queens_portfolio_filters_ajax;
				?>
				<div id="<?php echo esc_attr(sprintf('%s_%s_content', $kings_queens_portfolio_filters_id, $kings_queens_id)); ?>"
					class="portfolio_content kings_queens_tabs_content"
					data-blog-template="<?php echo esc_attr(kings_queens_storage_get('blog_template')); ?>"
					data-blog-style="<?php echo esc_attr(kings_queens_get_theme_option('blog_style')); ?>"
					data-posts-per-page="<?php echo esc_attr($kings_queens_ppp); ?>"
					data-post-type="<?php echo esc_attr($kings_queens_post_type); ?>"
					data-taxonomy="<?php echo esc_attr($kings_queens_taxonomy); ?>"
					data-cat="<?php echo esc_attr($kings_queens_id); ?>"
					data-parent-cat="<?php echo esc_attr($kings_queens_cat); ?>"
					data-need-content="<?php echo (false===$kings_queens_portfolio_need_content ? 'true' : 'false'); ?>"
				>
					<?php
					if ($kings_queens_portfolio_need_content) 
						kings_queens_show_portfolio_posts(array(
							'cat' => $kings_queens_id,
							'parent_cat' => $kings_queens_cat,
							'taxonomy' => $kings_queens_taxonomy,
							'post_type' => $kings_queens_post_type,
							'page' => 1,
							'sticky' => $kings_queens_sticky_out
							)
						);
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	} else {
		kings_queens_show_portfolio_posts(array(
			'cat' => $kings_queens_cat,
			'parent_cat' => $kings_queens_cat,
			'taxonomy' => $kings_queens_taxonomy,
			'post_type' => $kings_queens_post_type,
			'page' => 1,
			'sticky' => $kings_queens_sticky_out
			)
		);
	}

	kings_queens_show_layout(get_query_var('blog_archive_end'));

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>