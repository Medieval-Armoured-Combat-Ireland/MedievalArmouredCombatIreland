<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

$kings_queens_blog_style = explode('_', kings_queens_get_theme_option('blog_style'));
$kings_queens_columns = empty($kings_queens_blog_style[1]) ? 2 : max(2, $kings_queens_blog_style[1]);
$kings_queens_post_format = get_post_format();
$kings_queens_post_format = empty($kings_queens_post_format) ? 'standard' : str_replace('post-format-', '', $kings_queens_post_format);
$kings_queens_animation = kings_queens_get_theme_option('blog_animation');

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_portfolio post_layout_portfolio_'.esc_attr($kings_queens_columns).' post_format_'.esc_attr($kings_queens_post_format).(is_sticky() && !is_paged() ? ' sticky' : '') ); ?>
	<?php echo (!kings_queens_is_off($kings_queens_animation) ? ' data-animation="'.esc_attr(kings_queens_get_animation_classes($kings_queens_animation)).'"' : ''); ?>>
	<?php

	// Sticky label
	if ( is_sticky() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	$kings_queens_image_hover = kings_queens_get_theme_option('image_hover');
	// Featured image
	kings_queens_show_post_featured(array(
		'thumb_size' => kings_queens_get_thumb_size(strpos(kings_queens_get_theme_option('body_style'), 'full')!==false || $kings_queens_columns < 3 
								? 'masonry-big' 
								: 'masonry'),
		'show_no_image' => true,
		'class' => $kings_queens_image_hover == 'dots' ? 'hover_with_info' : '',
		'post_info' => $kings_queens_image_hover == 'dots' ? '<div class="post_info">'.esc_html(get_the_title()).'</div>' : ''
	));
	?>
</article>