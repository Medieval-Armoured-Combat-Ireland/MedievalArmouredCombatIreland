<?php
/**
 * Theme storage manipulations
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Get theme variable
if (!function_exists('kings_queens_storage_get')) {
	function kings_queens_storage_get($var_name, $default='') {
		global $KINGS_QUEENS_STORAGE;
		return isset($KINGS_QUEENS_STORAGE[$var_name]) ? $KINGS_QUEENS_STORAGE[$var_name] : $default;
	}
}

// Set theme variable
if (!function_exists('kings_queens_storage_set')) {
	function kings_queens_storage_set($var_name, $value) {
		global $KINGS_QUEENS_STORAGE;
		$KINGS_QUEENS_STORAGE[$var_name] = $value;
	}
}

// Check if theme variable is empty
if (!function_exists('kings_queens_storage_empty')) {
	function kings_queens_storage_empty($var_name, $key='', $key2='') {
		global $KINGS_QUEENS_STORAGE;
		if (!empty($key) && !empty($key2))
			return empty($KINGS_QUEENS_STORAGE[$var_name][$key][$key2]);
		else if (!empty($key))
			return empty($KINGS_QUEENS_STORAGE[$var_name][$key]);
		else
			return empty($KINGS_QUEENS_STORAGE[$var_name]);
	}
}

// Check if theme variable is set
if (!function_exists('kings_queens_storage_isset')) {
	function kings_queens_storage_isset($var_name, $key='', $key2='') {
		global $KINGS_QUEENS_STORAGE;
		if (!empty($key) && !empty($key2))
			return isset($KINGS_QUEENS_STORAGE[$var_name][$key][$key2]);
		else if (!empty($key))
			return isset($KINGS_QUEENS_STORAGE[$var_name][$key]);
		else
			return isset($KINGS_QUEENS_STORAGE[$var_name]);
	}
}

// Inc/Dec theme variable with specified value
if (!function_exists('kings_queens_storage_inc')) {
	function kings_queens_storage_inc($var_name, $value=1) {
		global $KINGS_QUEENS_STORAGE;
		if (empty($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = 0;
		$KINGS_QUEENS_STORAGE[$var_name] += $value;
	}
}

// Concatenate theme variable with specified value
if (!function_exists('kings_queens_storage_concat')) {
	function kings_queens_storage_concat($var_name, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (empty($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = '';
		$KINGS_QUEENS_STORAGE[$var_name] .= $value;
	}
}

// Get array (one or two dim) element
if (!function_exists('kings_queens_storage_get_array')) {
	function kings_queens_storage_get_array($var_name, $key, $key2='', $default='') {
		global $KINGS_QUEENS_STORAGE;
		if (empty($key2))
			return !empty($var_name) && !empty($key) && isset($KINGS_QUEENS_STORAGE[$var_name][$key]) ? $KINGS_QUEENS_STORAGE[$var_name][$key] : $default;
		else
			return !empty($var_name) && !empty($key) && isset($KINGS_QUEENS_STORAGE[$var_name][$key][$key2]) ? $KINGS_QUEENS_STORAGE[$var_name][$key][$key2] : $default;
	}
}

// Set array element
if (!function_exists('kings_queens_storage_set_array')) {
	function kings_queens_storage_set_array($var_name, $key, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if ($key==='')
			$KINGS_QUEENS_STORAGE[$var_name][] = $value;
		else
			$KINGS_QUEENS_STORAGE[$var_name][$key] = $value;
	}
}

// Set two-dim array element
if (!function_exists('kings_queens_storage_set_array2')) {
	function kings_queens_storage_set_array2($var_name, $key, $key2, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if (!isset($KINGS_QUEENS_STORAGE[$var_name][$key])) $KINGS_QUEENS_STORAGE[$var_name][$key] = array();
		if ($key2==='')
			$KINGS_QUEENS_STORAGE[$var_name][$key][] = $value;
		else
			$KINGS_QUEENS_STORAGE[$var_name][$key][$key2] = $value;
	}
}

// Merge array elements
if (!function_exists('kings_queens_storage_merge_array')) {
	function kings_queens_storage_merge_array($var_name, $key, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if ($key==='')
			$KINGS_QUEENS_STORAGE[$var_name] = array_merge($KINGS_QUEENS_STORAGE[$var_name], $value);
		else
			$KINGS_QUEENS_STORAGE[$var_name][$key] = array_merge($KINGS_QUEENS_STORAGE[$var_name][$key], $value);
	}
}

// Add array element after the key
if (!function_exists('kings_queens_storage_set_array_after')) {
	function kings_queens_storage_set_array_after($var_name, $after, $key, $value='') {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if (is_array($key))
			kings_queens_array_insert_after($KINGS_QUEENS_STORAGE[$var_name], $after, $key);
		else
			kings_queens_array_insert_after($KINGS_QUEENS_STORAGE[$var_name], $after, array($key=>$value));
	}
}

// Add array element before the key
if (!function_exists('kings_queens_storage_set_array_before')) {
	function kings_queens_storage_set_array_before($var_name, $before, $key, $value='') {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if (is_array($key))
			kings_queens_array_insert_before($KINGS_QUEENS_STORAGE[$var_name], $before, $key);
		else
			kings_queens_array_insert_before($KINGS_QUEENS_STORAGE[$var_name], $before, array($key=>$value));
	}
}

// Push element into array
if (!function_exists('kings_queens_storage_push_array')) {
	function kings_queens_storage_push_array($var_name, $key, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if ($key==='')
			array_push($KINGS_QUEENS_STORAGE[$var_name], $value);
		else {
			if (!isset($KINGS_QUEENS_STORAGE[$var_name][$key])) $KINGS_QUEENS_STORAGE[$var_name][$key] = array();
			array_push($KINGS_QUEENS_STORAGE[$var_name][$key], $value);
		}
	}
}

// Pop element from array
if (!function_exists('kings_queens_storage_pop_array')) {
	function kings_queens_storage_pop_array($var_name, $key='', $defa='') {
		global $KINGS_QUEENS_STORAGE;
		$rez = $defa;
		if ($key==='') {
			if (isset($KINGS_QUEENS_STORAGE[$var_name]) && is_array($KINGS_QUEENS_STORAGE[$var_name]) && count($KINGS_QUEENS_STORAGE[$var_name]) > 0) 
				$rez = array_pop($KINGS_QUEENS_STORAGE[$var_name]);
		} else {
			if (isset($KINGS_QUEENS_STORAGE[$var_name][$key]) && is_array($KINGS_QUEENS_STORAGE[$var_name][$key]) && count($KINGS_QUEENS_STORAGE[$var_name][$key]) > 0) 
				$rez = array_pop($KINGS_QUEENS_STORAGE[$var_name][$key]);
		}
		return $rez;
	}
}

// Inc/Dec array element with specified value
if (!function_exists('kings_queens_storage_inc_array')) {
	function kings_queens_storage_inc_array($var_name, $key, $value=1) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if (empty($KINGS_QUEENS_STORAGE[$var_name][$key])) $KINGS_QUEENS_STORAGE[$var_name][$key] = 0;
		$KINGS_QUEENS_STORAGE[$var_name][$key] += $value;
	}
}

// Concatenate array element with specified value
if (!function_exists('kings_queens_storage_concat_array')) {
	function kings_queens_storage_concat_array($var_name, $key, $value) {
		global $KINGS_QUEENS_STORAGE;
		if (!isset($KINGS_QUEENS_STORAGE[$var_name])) $KINGS_QUEENS_STORAGE[$var_name] = array();
		if (empty($KINGS_QUEENS_STORAGE[$var_name][$key])) $KINGS_QUEENS_STORAGE[$var_name][$key] = '';
		$KINGS_QUEENS_STORAGE[$var_name][$key] .= $value;
	}
}

// Call object's method
if (!function_exists('kings_queens_storage_call_obj_method')) {
	function kings_queens_storage_call_obj_method($var_name, $method, $param=null) {
		global $KINGS_QUEENS_STORAGE;
		if ($param===null)
			return !empty($var_name) && !empty($method) && isset($KINGS_QUEENS_STORAGE[$var_name]) ? $KINGS_QUEENS_STORAGE[$var_name]->$method(): '';
		else
			return !empty($var_name) && !empty($method) && isset($KINGS_QUEENS_STORAGE[$var_name]) ? $KINGS_QUEENS_STORAGE[$var_name]->$method($param): '';
	}
}

// Get object's property
if (!function_exists('kings_queens_storage_get_obj_property')) {
	function kings_queens_storage_get_obj_property($var_name, $prop, $default='') {
		global $KINGS_QUEENS_STORAGE;
		return !empty($var_name) && !empty($prop) && isset($KINGS_QUEENS_STORAGE[$var_name]->$prop) ? $KINGS_QUEENS_STORAGE[$var_name]->$prop : $default;
	}
}
?>