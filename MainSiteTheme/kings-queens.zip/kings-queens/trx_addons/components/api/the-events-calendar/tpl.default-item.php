<?php
/**
 * The style "default" of the Events
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.2
 */


$args = get_query_var('trx_addons_args_sc_events');

if ($args['slider']) {
	?><div class="swiper-slide"><?php
} else if ($args['columns'] > 1) {
	?><div class="<?php echo esc_attr(trx_addons_get_column_class(1, $args['columns'])); ?>"><?php
}
        ?><div class="sc_events_item"><?php
        // Event's date
        $date = tribe_get_start_date(null, true, 'F j');
        if (empty($date)) $date = get_the_date('F j');

        $date_end = tribe_get_end_date(null, true, 'Y');
        if (empty($date_end)) $date_end = get_the_date('Y');

        ?><h1 class="sc_events_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><div class="event-content"><div class="sc_events_date"><?php
                echo esc_html($date); ?><br><?php echo esc_html($date_end);
                ?></div><?php
        // Event's title
        ?><?php
        ?><div class="sc_events_item_descr"><?php the_excerpt(); ?><a href="<?php the_permalink(); ?>" class="sc_button sc_button_bordered"><?php esc_html_e('Take part','kings-queens');?></a><?php
                    ?></div><?php
        // Arrow (button)
                ?></div></div><?php

        if ($args['slider'] || $args['columns'] > 1) {
        ?></div><?php
}

?>