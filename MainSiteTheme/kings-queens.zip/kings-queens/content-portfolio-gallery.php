<?php
/**
 * The Gallery template to display posts
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage KINGS_QUEENS
 * @since KINGS_QUEENS 1.0
 */

$kings_queens_blog_style = explode('_', kings_queens_get_theme_option('blog_style'));
$kings_queens_columns = empty($kings_queens_blog_style[1]) ? 2 : max(2, $kings_queens_blog_style[1]);
$kings_queens_post_format = get_post_format();
$kings_queens_post_format = empty($kings_queens_post_format) ? 'standard' : str_replace('post-format-', '', $kings_queens_post_format);
$kings_queens_animation = kings_queens_get_theme_option('blog_animation');
$kings_queens_image = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_portfolio post_layout_gallery post_layout_gallery_'.esc_attr($kings_queens_columns).' post_format_'.esc_attr($kings_queens_post_format) ); ?>
	<?php echo (!kings_queens_is_off($kings_queens_animation) ? ' data-animation="'.esc_attr(kings_queens_get_animation_classes($kings_queens_animation)).'"' : ''); ?>
	data-size="<?php if (!empty($kings_queens_image[1]) && !empty($kings_queens_image[2])) echo intval($kings_queens_image[1]) .'x' . intval($kings_queens_image[2]); ?>"
	data-src="<?php if (!empty($kings_queens_image[0])) echo esc_url($kings_queens_image[0]); ?>"
	>

	<?php

	// Sticky label
	if ( is_sticky() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	$kings_queens_image_hover = 'icon';	
	if (in_array($kings_queens_image_hover, array('icons', 'zoom'))) $kings_queens_image_hover = 'dots';
	$kings_queens_components = kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('meta_parts'));
	$kings_queens_counters = kings_queens_array_get_keys_by_value(kings_queens_get_theme_option('counters'));
	kings_queens_show_post_featured(array(
		'hover' => $kings_queens_image_hover,
		'thumb_size' => kings_queens_get_thumb_size( strpos(kings_queens_get_theme_option('body_style'), 'full')!==false || $kings_queens_columns < 3 ? 'masonry-big' : 'masonry' ),
		'thumb_only' => true,
		'show_no_image' => true,
		'post_info' => '<div class="post_details">'
							. '<h2 class="post_title"><a href="'.esc_url(get_permalink()).'">'. esc_html(get_the_title()) . '</a></h2>'
							. '<div class="post_description">'
								. (!empty($kings_queens_components)
										? kings_queens_show_post_meta(apply_filters('kings_queens_filter_post_meta_args', array(
											'components' => $kings_queens_components,
											'counters' => $kings_queens_counters,
											'seo' => false,
											'echo' => false
											), $kings_queens_blog_style[0], $kings_queens_columns))
										: '')
								. '<div class="post_description_content">'
									. apply_filters('the_excerpt', get_the_excerpt())
								. '</div>'
								. '<a href="'.esc_url(get_permalink()).'" class="theme_button post_readmore"><span class="post_readmore_label">' . esc_html__('Learn more', 'kings-queens') . '</span></a>'
							. '</div>'
						. '</div>'
	));
	?>
</article>