<div class="front_page_section front_page_section_woocommerce<?php
			$kings_queens_scheme = kings_queens_get_theme_option('front_page_woocommerce_scheme');
			if (!kings_queens_is_inherit($kings_queens_scheme)) echo ' scheme_'.esc_attr($kings_queens_scheme);
			echo ' front_page_section_paddings_'.esc_attr(kings_queens_get_theme_option('front_page_woocommerce_paddings'));
		?>"<?php
		$kings_queens_css = '';
		$kings_queens_bg_image = kings_queens_get_theme_option('front_page_woocommerce_bg_image');
		if (!empty($kings_queens_bg_image)) 
			$kings_queens_css .= 'background-image: url('.esc_url(kings_queens_get_attachment_url($kings_queens_bg_image)).');';
		if (!empty($kings_queens_css))
			echo ' style="' . esc_attr($kings_queens_css) . '"';
?>><?php
	// Add anchor
	$kings_queens_anchor_icon = kings_queens_get_theme_option('front_page_woocommerce_anchor_icon');	
	$kings_queens_anchor_text = kings_queens_get_theme_option('front_page_woocommerce_anchor_text');	
	if ((!empty($kings_queens_anchor_icon) || !empty($kings_queens_anchor_text)) && shortcode_exists('trx_sc_anchor')) {
		echo do_shortcode('[trx_sc_anchor id="front_page_section_woocommerce"'
										. (!empty($kings_queens_anchor_icon) ? ' icon="'.esc_attr($kings_queens_anchor_icon).'"' : '')
										. (!empty($kings_queens_anchor_text) ? ' title="'.esc_attr($kings_queens_anchor_text).'"' : '')
										. ']');
	}
	?>
	<div class="front_page_section_inner front_page_section_woocommerce_inner<?php
			if (kings_queens_get_theme_option('front_page_woocommerce_fullheight'))
				echo ' kings_queens-full-height sc_layouts_flex sc_layouts_columns_middle';
			?>"<?php
			$kings_queens_css = '';
			$kings_queens_bg_mask = kings_queens_get_theme_option('front_page_woocommerce_bg_mask');
			$kings_queens_bg_color = kings_queens_get_theme_option('front_page_woocommerce_bg_color');
			if (!empty($kings_queens_bg_color) && $kings_queens_bg_mask > 0)
				$kings_queens_css .= 'background-color: '.esc_attr($kings_queens_bg_mask==1
																	? $kings_queens_bg_color
																	: kings_queens_hex2rgba($kings_queens_bg_color, $kings_queens_bg_mask)
																).';';
			if (!empty($kings_queens_css))
				echo ' style="' . esc_attr($kings_queens_css) . '"';
	?>>
		<div class="front_page_section_content_wrap front_page_section_woocommerce_content_wrap content_wrap woocommerce">
			<?php
			// Content wrap with title and description
			$kings_queens_caption = kings_queens_get_theme_option('front_page_woocommerce_caption');
			$kings_queens_description = kings_queens_get_theme_option('front_page_woocommerce_description');
			if (!empty($kings_queens_caption) || !empty($kings_queens_description) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				// Caption
				if (!empty($kings_queens_caption) || (current_user_can('edit_theme_options') && is_customize_preview())) {
					?><h2 class="front_page_section_caption front_page_section_woocommerce_caption front_page_block_<?php echo !empty($kings_queens_caption) ? 'filled' : 'empty'; ?>"><?php
						echo wp_kses($kings_queens_caption, 'kings_queens_kses_content');
					?></h2><?php
				}
			
				// Description (text)
				if (!empty($kings_queens_description) || (current_user_can('edit_theme_options') && is_customize_preview())) {
					?><div class="front_page_section_description front_page_section_woocommerce_description front_page_block_<?php echo !empty($kings_queens_description) ? 'filled' : 'empty'; ?>"><?php
						echo wp_kses(wpautop($kings_queens_description), 'kings_queens_kses_content');
					?></div><?php
				}
			}
		
			// Content (widgets)
			?><div class="front_page_section_output front_page_section_woocommerce_output list_products shop_mode_thumbs"><?php 
				$kings_queens_woocommerce_sc = kings_queens_get_theme_option('front_page_woocommerce_products');
				if ($kings_queens_woocommerce_sc == 'products') {
					$kings_queens_woocommerce_sc_ids = kings_queens_get_theme_option('front_page_woocommerce_products_per_page');
					$kings_queens_woocommerce_sc_per_page = count(explode(',', $kings_queens_woocommerce_sc_ids));
				} else {
					$kings_queens_woocommerce_sc_per_page = max(1, (int) kings_queens_get_theme_option('front_page_woocommerce_products_per_page'));
				}
				$kings_queens_woocommerce_sc_columns = max(1, min($kings_queens_woocommerce_sc_per_page, (int) kings_queens_get_theme_option('front_page_woocommerce_products_columns')));
				echo do_shortcode("[{$kings_queens_woocommerce_sc}"
									. ($kings_queens_woocommerce_sc == 'products' 
											? ' ids="'.esc_attr($kings_queens_woocommerce_sc_ids).'"' 
											: '')
									. ($kings_queens_woocommerce_sc == 'product_category' 
											? ' category="'.esc_attr(kings_queens_get_theme_option('front_page_woocommerce_products_categories')).'"' 
											: '')
									. ($kings_queens_woocommerce_sc != 'best_selling_products' 
											? ' orderby="'.esc_attr(kings_queens_get_theme_option('front_page_woocommerce_products_orderby')).'"'
											  . ' order="'.esc_attr(kings_queens_get_theme_option('front_page_woocommerce_products_order')).'"' 
											: '')
									. ' per_page="'.esc_attr($kings_queens_woocommerce_sc_per_page).'"' 
									. ' columns="'.esc_attr($kings_queens_woocommerce_sc_columns).'"' 
									. ']');
			?></div>
		</div>
	</div>
</div>