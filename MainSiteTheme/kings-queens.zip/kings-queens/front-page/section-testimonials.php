<div class="front_page_section front_page_section_testimonials<?php
			$kings_queens_scheme = kings_queens_get_theme_option('front_page_testimonials_scheme');
			if (!kings_queens_is_inherit($kings_queens_scheme)) echo ' scheme_'.esc_attr($kings_queens_scheme);
			echo ' front_page_section_paddings_'.esc_attr(kings_queens_get_theme_option('front_page_testimonials_paddings'));
		?>"<?php
		$kings_queens_css = '';
		$kings_queens_bg_image = kings_queens_get_theme_option('front_page_testimonials_bg_image');
		if (!empty($kings_queens_bg_image)) 
			$kings_queens_css .= 'background-image: url('.esc_url(kings_queens_get_attachment_url($kings_queens_bg_image)).');';
		if (!empty($kings_queens_css))
			echo ' style="' . esc_attr($kings_queens_css) . '"';
?>><?php
	// Add anchor
	$kings_queens_anchor_icon = kings_queens_get_theme_option('front_page_testimonials_anchor_icon');	
	$kings_queens_anchor_text = kings_queens_get_theme_option('front_page_testimonials_anchor_text');	
	if ((!empty($kings_queens_anchor_icon) || !empty($kings_queens_anchor_text)) && shortcode_exists('trx_sc_anchor')) {
		echo do_shortcode('[trx_sc_anchor id="front_page_section_testimonials"'
										. (!empty($kings_queens_anchor_icon) ? ' icon="'.esc_attr($kings_queens_anchor_icon).'"' : '')
										. (!empty($kings_queens_anchor_text) ? ' title="'.esc_attr($kings_queens_anchor_text).'"' : '')
										. ']');
	}
	?>
	<div class="front_page_section_inner front_page_section_testimonials_inner<?php
			if (kings_queens_get_theme_option('front_page_testimonials_fullheight'))
				echo ' kings_queens-full-height sc_layouts_flex sc_layouts_columns_middle';
			?>"<?php
			$kings_queens_css = '';
			$kings_queens_bg_mask = kings_queens_get_theme_option('front_page_testimonials_bg_mask');
			$kings_queens_bg_color = kings_queens_get_theme_option('front_page_testimonials_bg_color');
			if (!empty($kings_queens_bg_color) && $kings_queens_bg_mask > 0)
				$kings_queens_css .= 'background-color: '.esc_attr($kings_queens_bg_mask==1
																	? $kings_queens_bg_color
																	: kings_queens_hex2rgba($kings_queens_bg_color, $kings_queens_bg_mask)
																).';';
			if (!empty($kings_queens_css))
				echo ' style="' . esc_attr($kings_queens_css) . '"';
	?>>
		<div class="front_page_section_content_wrap front_page_section_testimonials_content_wrap content_wrap">
			<?php
			// Caption
			$kings_queens_caption = kings_queens_get_theme_option('front_page_testimonials_caption');
			if (!empty($kings_queens_caption) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><h2 class="front_page_section_caption front_page_section_testimonials_caption front_page_block_<?php echo !empty($kings_queens_caption) ? 'filled' : 'empty'; ?>"><?php echo wp_kses($kings_queens_caption, 'kings_queens_kses_content'); ?></h2><?php
			}
		
			// Description (text)
			$kings_queens_description = kings_queens_get_theme_option('front_page_testimonials_description');
			if (!empty($kings_queens_description) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><div class="front_page_section_description front_page_section_testimonials_description front_page_block_<?php echo !empty($kings_queens_description) ? 'filled' : 'empty'; ?>"><?php echo wp_kses(wpautop($kings_queens_description), 'kings_queens_kses_content'); ?></div><?php
			}
		
			// Content (widgets)
			?><div class="front_page_section_output front_page_section_testimonials_output"><?php 
				if (is_active_sidebar('front_page_testimonials_widgets')) {
					dynamic_sidebar( 'front_page_testimonials_widgets' );
				} else if (current_user_can( 'edit_theme_options' )) {
					if (!kings_queens_exists_trx_addons())
						kings_queens_customizer_need_trx_addons_message();
					else
						kings_queens_customizer_need_widgets_message('front_page_testimonials_caption', 'ThemeREX Addons - Testimonials');
				}
			?></div>
		</div>
	</div>
</div>