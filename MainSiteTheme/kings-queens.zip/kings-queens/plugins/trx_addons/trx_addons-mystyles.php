<?php
// Add plugin-specific colors and fonts to the custom CSS
if (!function_exists('kings_queens_trx_addons_get_mycss')) {
	add_filter('kings_queens_filter_get_css', 'kings_queens_trx_addons_get_mycss', 10, 4);
	function kings_queens_trx_addons_get_mycss($css, $args) {

        if (isset($css['fonts']) && isset($args['fonts'])) {
            $fonts = $args['fonts'];
            $css['fonts'] .= <<<CSS
            
            .top_panel .sc_layouts_row.sc_layouts_row_type_compact .sc_layouts_menu_nav,
            .events-popup-item > span > span,
            .sc_events_full .sc_events_date_month > span > span,
            .body_wrap .page_wrap .BigWhiteTexts,
            .body_wrap .page_wrap .SmallWhiteTexts,
            .sc_skills .sc_skills_item_title,
            .sc_skills_counter .sc_skills_total,
            .sc_skills_pie.sc_skills_compact_off .sc_skills_item_title,
            .sc_skills_pie.sc_skills_compact_off .sc_skills_item_title,
            span.sc_form_field_title,
            .sc_testimonials_item_content:before,
            blockquote:before,
            .trx_addons_dropcap {
                {$fonts['h1_font-family']}
            }
            .sc_slider_controller_info,
            .body_wrap .page_wrap .SmallTextsLink,
            .body_wrap .page_wrap .SmallTexts,
            .widget_area .post_item .post_title, aside .post_item .post_title, 
            .mejs-controls .mejs-time * {
                {$fonts['p_font-family']}
            }

CSS;
        }

        if (isset($css['colors']) && isset($args['colors'])) {
            $colors = $args['colors'];
            $css['colors'] .= <<<CSS
            
            /* Inline colors */
            .trx_addons_accent,
            .trx_addons_accent_big,
            .trx_addons_accent > a,
            .trx_addons_accent > * {
                color: {$colors['text_link']};
            }
            .trx_addons_accent_hovered,
            .trx_addons_accent_hovered,
            .trx_addons_accent_hovered > a,
            .trx_addons_accent_hovered > * {
                color: {$colors['text_dark']};
            }
            .trx_addons_accent_bg {
                background-color: {$colors['text_link']};
                color: {$colors['bg_color']};
            }

            
            /* Tooltip */
            .trx_addons_tooltip {
                color: {$colors['text_dark']};
                border-color: {$colors['text_dark']};
            }
            .trx_addons_tooltip:before {
                background-color: {$colors['text_dark']};
                color: {$colors['inverse_link']};
            }
            .trx_addons_tooltip:after {
                border-top-color: {$colors['text_dark']};
            }
            .scheme_dark .trx_addons_tooltip:before {
                background-color: {$colors['text_link']};
                color: {$colors['inverse_link']};
            }
            .scheme_dark .trx_addons_tooltip:after {
                border-top-color: {$colors['text_link']};
            }
            
            
            /* Dropcaps */
            .trx_addons_dropcap_style_1 {
                background-color: {$colors['text_link']};
                color: {$colors['bg_color']};
            }
            .trx_addons_dropcap_style_2 {
                background-color: {$colors['bg_color_0']};
                color: {$colors['text_dark']};
            }
            
            /* Blockqoute */
            blockquote {
                color: {$colors['inverse_link']};
                background-color: {$colors['text_link']};
            }
            blockquote cite a,
            blockquote > a, blockquote > p > a,
            blockquote > cite, blockquote > p > cite {
                color: {$colors['inverse_link']};
            }
            blockquote cite a:hover,
            blockquote > a, blockquote > p > a:hover {
                color: {$colors['text_dark']};
            }
            blockquote:before {
                color: {$colors['inverse_link']};
            }
            
            /* Lists */
            ul[class*="trx_addons_list"].trx_addons_list_without li{
                color: {$colors['alter_text']};
            }
            
          
            
            /* Table */
            table th {
                color: {$colors['text']};
                background-color: {$colors['text_hover']};
            }
            table th, table th + th, table td + th  {
                border-color: {$colors['bg_color_02']};
            }
            table td, table th + td, table td + td {
                color: {$colors['text']};
                border-color: {$colors['alter_bd_color']};
            }
            table > tbody > tr:nth-child(2n+1) > td {
                background-color: {$colors['alter_bg_hover']};
            }
            table > tbody > tr:nth-child(2n) > td {
                background-color: {$colors['bd_color']};
            }
            th a {
                color: {$colors['text_link']};
            }

            /* Main menu */
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li>a {
                color: {$colors['text']} !important;
            }
            .sc_layouts_menu_nav>li>a {
                color: {$colors['text_dark']} !important;
            }
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li>a:hover,
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li.sfHover>a,
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li.current-menu-item>a,
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li.current-menu-parent>a,
            .top_panel_custom_756 > .vc_row:not(.sc_layouts_row_fixed) .sc_layouts_menu_nav>li.current-menu-ancestor>a,
            .sc_layouts_menu_nav>li>a:hover,
            .sc_layouts_menu_nav>li.sfHover>a,
            .sc_layouts_menu_nav>li.current-menu-item>a,
            .sc_layouts_menu_nav>li.current-menu-parent>a,
            .sc_layouts_menu_nav>li.current-menu-ancestor>a {
                color: {$colors['text_link']} !important;
            }
            /* Dropdown menu */
            .sc_layouts_menu_nav>li>ul:before,
            .sc_layouts_menu_nav>li ul {
                background-color: {$colors['text_hover']};
            }
            .sc_layouts_menu_popup .sc_layouts_menu_nav>li>a,
            .sc_layouts_menu_nav>li li>a {
                color: {$colors['text_light']} !important;
            }
            .sc_layouts_menu_nav>li li>a:hover:after,
            .sc_layouts_menu_popup .sc_layouts_menu_nav>li>a:hover,
            .sc_layouts_menu_popup .sc_layouts_menu_nav>li.sfHover>a,
            .sc_layouts_menu_nav>li li>a:hover,
            .sc_layouts_menu_nav>li li.sfHover>a,
            .sc_layouts_menu_nav>li li.current-menu-item>a,
            .sc_layouts_menu_nav>li li.current-menu-parent>a,
            .sc_layouts_menu_nav>li li.current-menu-ancestor>a {
                color: {$colors['text_link']} !important;
                background-color: {$colors['bg_color_0']};
            }
            
            /* Breadcrumbs */
            .sc_layouts_title_caption {
                color: {$colors['text_dark']};
            }
            .sc_layouts_title_breadcrumbs,
            .sc_layouts_title_breadcrumbs a {
                color: {$colors['text_link']} !important;
            }
            .breadcrumbs_item.current{
                color: {$colors['text_link']} !important;
            }
            .sc_layouts_title_breadcrumbs a:hover {
                color: {$colors['text_dark']} !important;
            }
            
            /* Slider */
            .slider_container .slider_pagination_wrap .swiper-pagination-bullet,
            .slider_outer .slider_pagination_wrap .swiper-pagination-bullet,
            .swiper-pagination-custom .swiper-pagination-button {
                border-color: {$colors['text_hover']};
                background-color: {$colors['bg_color']};
            }
            .swiper-pagination-custom .swiper-pagination-button.swiper-pagination-button-active,
            .slider_container .slider_pagination_wrap .swiper-pagination-bullet.swiper-pagination-bullet-active,
            .slider_outer .slider_pagination_wrap .swiper-pagination-bullet.swiper-pagination-bullet-active,
            .slider_container .slider_pagination_wrap .swiper-pagination-bullet:hover,
            .slider_outer .slider_pagination_wrap .swiper-pagination-bullet:hover {
                border-color: {$colors['inverse_link']};
                background-color: {$colors['text_link']};
            }
            
            .sc_slider_controls .slider_controls_wrap > a,
            .slider_container.slider_controls_side .slider_controls_wrap > a,
            .slider_outer_controls_side .slider_controls_wrap > a {
                color: {$colors['text_link']};
                background-color: {$colors['bg_color_0']};
                border-color: {$colors['bg_color_0']};
            }
            .sc_slider_controls .slider_controls_wrap > a:hover,
            .slider_container.slider_controls_side .slider_controls_wrap > a:hover,
            .slider_outer_controls_side .slider_controls_wrap > a:hover {
                color: {$colors['text_light']};
                background-color: {$colors['bg_color_0']};
                border-color: {$colors['bg_color_0']};
            }
            
            
            /* Layouts */
            .sc_layouts_logo .logo_text {
                color: {$colors['text_dark']};
            }
            

            /* Shortcodes */
            .sc_skills_pie.sc_skills_compact_off .sc_skills_total {
                color: {$colors['text_dark']};
            }
            .sc_skills_pie.sc_skills_compact_off .sc_skills_item_title {
                color: {$colors['text']};
            }
            .sc_countdown .sc_countdown_label{
                color: {$colors['text_dark']};
                background: {$colors['bg_color_0']};
            }
            .sc_countdown_default .sc_countdown_digits span {
                color: {$colors['text_hover']};
                background: {$colors['bg_color_0']};
            }
            
            /* Audio */
            .trx_addons_audio_player.without_cover,
            .format-audio .post_featured.without_thumb .post_audio {
                background: {$colors['text_link']} !important;
            }
            .format-audio .post_featured.without_thumb .mejs-controls,
            .trx_addons_audio_player.without_cover .mejs-controls {
                background: {$colors['text_link']};
            }
            .format-audio .post_featured.without_thumb .mejs-container,
            .trx_addons_audio_player.without_cover .mejs-container {
                background: {$colors['text_link']};
            }
            .format-audio .post_featured.without_thumb .post_audio_author,
            .trx_addons_audio_player.without_cover .audio_author,
            .format-audio .post_featured.without_thumb .mejs-controls .mejs-time,
            .trx_addons_audio_player.without_cover .mejs-time {
                color: {$colors['text']};
            }
            .trx_addons_audio_player.without_cover,
            .format-audio .post_featured.without_thumb .post_audio {
                background-color: {$colors['alter_bg_color']};
                border-color: {$colors['alter_bg_color']};
            }
            .mejs-controls .mejs-button > button {
                background: {$colors['bg_color']} !important;
                color: {$colors['text_link']}!important;
            }
            .mejs-controls .mejs-button > button:hover {
                background: {$colors['text_hover']} !important;
                color: {$colors['text_light']}!important;
            }
            .mejs-controls .mejs-time-rail .mejs-time-total,
            .mejs-controls .mejs-time-rail .mejs-time-loaded,
            .mejs-controls .mejs-volume-slider .mejs-volume-total,
            .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-total {
                background: {$colors['inverse_link_03']};
            }
            .mejs-controls .mejs-time-rail .mejs-time-hovered,
            .mejs-controls .mejs-time-rail .mejs-time-current,
            .mejs-controls .mejs-volume-slider .mejs-volume-current,
            .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current {
                background: {$colors['bg_color']};
            }
            .mejs-controls .mejs-time *,
            .trx_addons_audio_player.without_cover .audio_author,
            .format-audio .post_featured.without_thumb .post_audio_author,
            .trx_addons_audio_player.without_cover .audio_caption,
            .format-audio .post_featured.without_thumb .post_audio_title {
                color: {$colors['inverse_link']};
            }
            
            /* Video */
            .trx_addons_video_player.with_cover .video_hover,
            .format-video .post_featured.with_thumb .post_video_hover {
                color: {$colors['text_light']};
                background-color: {$colors['text_link']};
            }
            .trx_addons_video_player.with_cover .video_hover:hover,
            .format-video .post_featured.with_thumb .post_video_hover:hover {
                color: {$colors['text_light']};
                background-color: {$colors['text_hover']};
            }
            
            
            /* Price */
            .sc_price_item {
                color: {$colors['text_dark']};
                background-color: {$colors['bg_color']};
                border-color: {$colors['extra_light']};
            }
            .sc_price_item:hover {
                color: {$colors['text_dark']};
                background-color: {$colors['bg_color']};
                border-color: {$colors['extra_light']};
            }
            .sc_price_item .sc_price_item_price,
            .price-top {
                background-color: {$colors['bd_color']};
            }
            .sc_price_item:hover .sc_price_item_title,
            .sc_price_item .sc_price_item_title,
            .sc_price_item .sc_price_item_title a {
                color: {$colors['text_link']};
            }
            .sc_price_item:hover .sc_price_item_title a {
                color: {$colors['text_link']};
            }
            .sc_price_item .sc_price_item_price {
                color: {$colors['text_dark']};
            }
            .sc_price_item .sc_price_item_description{
                color: {$colors['text']};
            }
            .sc_price_item .sc_price_item_details {
                color: {$colors['text']};
            }
            .sc_price_item_price .sc_price_item_price_value {
                color: {$colors['text_dark']};
            }
            
            .comment-author-link {
                color: {$colors['text_link']};
            }
            span.sc_form_field_title {
                color: {$colors['text_dark']};
            }
            .sidebar[class*="scheme_"] .widget .widget_title:before,
            .sidebar[class*="scheme_"] .widget .widget_title:after {
                background-color: {$colors['text_link']};
            }
            .sc_layouts_item_icon {
                color: {$colors['text_link']};
            }
            
            .footer_wrap .widget_contacts .contacts_wrap:before {
                background-color: {$colors['text_light']};
            }
            .sc_skills .sc_skills_item_title,
            .sc_skills_counter .sc_skills_total,
            .sc_skills_pie.sc_skills_compact_off .sc_skills_item_title,
            .scheme_self.footer_wrap .widgettitle {
                color: {$colors['text_dark']};
            }
            .footer_wrap a {
                color: {$colors['alter_text']} !important;
            }
            .footer_wrap a:hover {
                color: {$colors['text_link']} !important;
            }
            .sc_skills_counter .sc_skills_icon {
                background-color: {$colors['bd_color']};
                color: {$colors['text_link']};
            }
            .sc_price_item_details ul li + li {
                border-color: {$colors['bd_color']};
            }
            .sc_action_item_default.with_image .sc_action_item_title,
            .sc_testimonials_item_author_subtitle {
                color: {$colors['text_dark']};
            }
            .sc_testimonials_item_content {
                color: {$colors['text']};
            }
            .sc_icons_item_description  a:hover,
            .sc_action_item_default.with_image .sc_action_item_icon {
                color: {$colors['text_link']};
            }
            .post_layout_excerpt.sticky {
                background-color: {$colors['alter_bg_hover']};
            }
            div.esg-filters,
            .woocommerce nav.woocommerce-pagination ul,
            .comments_pagination,
            .nav-links,
            .page_links {
                border-color: {$colors['bd_color']};
            }
            .sc_events_full .sc_events_item:before,
            .sc_content_light:before {
                background-color: {$colors['bg_color']};
            }
            .sc_events_item_descr,
            .sc_icons .sc_icons_item_title {
                color: {$colors['text_dark']};
            }
            .sc_icons_item_description  a,
            .sc_icons_item_description {
                color: {$colors['text']};
            }
            .sc_promo .sc_promo_descr {
                color: {$colors['text']};
            }
            .sc_team_short .sc_team_item {
                background-color: {$colors['bg_color']};
            }
            .sc_team_short .sc_team_item_title a{
                color: {$colors['text_link']};
            }
            .sc_team_short .sc_team_item_title a:hover {
                color: {$colors['text_hover']};
            }
            .body_wrap .page_wrap .SmallTextsLink span,
            .sc_price_item .sc_price_item_subtitle,
            .team-country,
            .team-club {
                color: {$colors['text_link']};
            }
            .sc_title.italic h3,
            .body_wrap .page_wrap .custom.tparrows:before,
            .body_wrap .page_wrap .SmallTextsLink:hover {
                color: {$colors['text_link']} !important;
            }
            .body_wrap .page_wrap .custom.tparrows:hover:before {
                color: {$colors['text_light']} !important;
            }
            .scheme_dark .sc_item_descr {
                color: {$colors['text_light']};
            }
            .sc_icons .sc_icons_icon {
                background-color: {$colors['bg_color']};
            }
            .sc_icons .sc_icons_item_linked:hover .sc_icons_icon {
                background-color: {$colors['text_link']};
                color: {$colors['text_light']};
            }
            .sc_events_date {
                color: {$colors['text_link']};
            }
            .sc_events_default .sc_events_item {
                background-color: {$colors['bg_color_0']};
            }
            .sc_icons .sc_icons_item_linked:hover .sc_icons_item_title {
                color: {$colors['text_link']};
            }
            .sc_events_full .sc_events_item_descr {
                color: {$colors['text']};
            }
            .events-popup {
                background-color: {$colors['bg_color']};
            }
            .sc_slider_controller_titles .sc_slider_controller_info_title,
            .sc_slider_controller_info {
                color: {$colors['text_light']};
            }
            .sc_blogger_modern .sc_blogger_item:before,
            .sc_slider_controller_titles .slider-slide.swiper-slide-active:before {
                background-color: {$colors['bg_color']};
            }
            .sc_slider_controller_titles .slider-slide.swiper-slide-active .sc_slider_controller_info_title {
                color: {$colors['text']};
            }
            .sc_layouts_cart:hover .sc_layouts_item_details_line1 {
                color: {$colors['text_link']};
            }
            .sc_layouts_item_details_line1 {
                color: {$colors['text_dark']};
            }
            .scheme_self.sc_layouts_row_type_normal .search_wrap .search_submit:hover:before,
            .sc_layouts_row_type_normal .search_wrap .search_field {
                color: {$colors['bg_color']};
            }
            header .scheme_self.sc_layouts_row_type_normal .search_wrap .search_submit:hover:before{
              color: {$colors['text_dark']};
            }
          
            .sc_layouts_row_type_normal .search_wrap .search_submit:before,
            .sc_layouts_row_type_normal .search_wrap .search_field:hover,
            .sc_layouts_row_type_normal .search_wrap .search_field:focus {
                color: {$colors['text_link']};
            }
            .sc_layouts_row_type_compact .sc_layouts_menu_nav > li:first-child:after,
            .sc_layouts_row_type_compact .sc_layouts_menu_nav > li:before {
                background-color: {$colors['text_link']};
            }
            
            .tribe-events-notices {
                color: {$colors['text']};
                border-color: {$colors['text_link']};
                background-color: {$colors['input_bg_color']};
            }
            .esgbox-share__button {
                color: {$colors['inverse_link']};
            }
            
CSS;
		}

		return $css;
	}
}
?>